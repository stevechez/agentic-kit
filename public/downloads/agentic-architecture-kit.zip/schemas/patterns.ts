import { z } from "zod";

export const ToolCallEnvelopeSchema = z.object({
  callId: z.string().uuid({ message: "callId must be a valid UUIDv4" }),
  timestamp: z.number().int().positive(),
  toolName: z.enum([
    "queryDatabase",
    "sendCustomerAlert",
    "bookCalendarSlot",
    "fetchKnowledgeBase"
  ]),
  idempotencyKey: z.string().min(16),
  arguments: z.record(z.string(), z.unknown()),
  metadata: z.object({
    userId: z.string(),
    organizationId: z.string(),
    traceId: z.string()
  })
});

export type ToolCallEnvelope = z.infer<typeof ToolCallEnvelopeSchema>;

export const AgentDecisionOutputSchema = z.object({
  status: z.enum(["completed", "requires_clarification", "escalation_required"]),
  confidenceScore: z.number().min(0).max(1),
  reasoningSummary: z.string().max(280).describe("Brief trace of rationale"),
  actionablePayload: z.object({
    actionType: z.string(),
    parameters: z.record(z.string(), z.unknown()),
    directResponseToUser: z.string()
  }),
  citations: z.array(
    z.object({
      sourceId: z.string(),
      documentTitle: z.string(),
      extractedFact: z.string()
    })
  ).default([])
});

export type AgentDecisionOutput = z.infer<typeof AgentDecisionOutputSchema>;

export function validateToolExecution(
  rawInput: unknown,
  allowedTools: string[]
): { success: boolean; data?: ToolCallEnvelope; error?: string } {
  const result = ToolCallEnvelopeSchema.safeParse(rawInput);
  
  if (!result.success) {
    return {
      success: false,
      error: `Schema validation failed: ${result.error.issues.map(i => i.message).join(", ")}`
    };
  }

  if (!allowedTools.includes(result.data.toolName)) {
    return {
      success: false,
      error: `Unauthorized tool call: '${result.data.toolName}' is outside runtime scope.`
    };
  }

  return { success: true, data: result.data };
}
