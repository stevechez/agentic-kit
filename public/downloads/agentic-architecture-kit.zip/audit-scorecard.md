# The 10-Point Agentic Production Audit & Readiness Scorecard
**The Engineering Pre-Flight Protocol for Autonomous LLM Workflows**

---

### How to Score Your System
Evaluate each of the 10 production categories against your codebase. 
* Award **10 points** if the architectural pattern is completely enforced in deterministic code.
* Award **5 points** if partially handled (e.g., covered only via prompt instructions).
* Award **0 points** if unhandled or relied entirely on model compliance.

---

### 1. Structured Outputs
- [ ] Model outputs are validated through schemas (e.g., Zod, Pydantic) before entering downstream logic.
- [ ] Application code catches schema parsing errors and retries with repair instructions instead of crashing.
*Score: ___ / 10*

### 2. Tool Call Validation
- [ ] Tool inputs pass schema and range validations prior to triggering database or API operations.
- [ ] User authorizations and session privileges are re-checked at the tool execution boundary.
*Score: ___ / 10*

### 3. State Management
- [ ] Agent execution is idempotent; repeated tool calls with the same key do not duplicate mutations.
- [ ] State recovers reliably if the server process terminates mid-execution.
*Score: ___ / 10*

### 4. Context Control
- [ ] Fixed token budgets cap conversation history, system instructions, and dynamic RAG chunks.
- [ ] Stale tool outputs and intermediate turns are summarized or pruned systematically.
*Score: ___ / 10*

### 5. Failure & Retry Logic
- [ ] Remote LLM APIs and tools are wrapped with backoff retries, circuit breakers, and timeouts.
- [ ] Dead-letter queues catch unrecoverable transactions for asynchronous human escalation.
*Score: ___ / 10*

### 6. Hallucination Boundaries
- [ ] Deterministic checks block models from answering without verified source records.
- [ ] The model is explicitly constrained to return an empty schema when data is missing.
*Score: ___ / 10*

### 7. Token Economics
- [ ] Per-task and per-user cost metrics are calculated and logged after each run.
- [ ] Hard token and billing limits terminate run loops that drift into excessive cycles.
*Score: ___ / 10*

### 8. Observability & Tracing
- [ ] Structured logs track system prompts, user turns, tool inputs, latency, and token consumption.
- [ ] Every run receives a traceable correlation ID that follows the workflow through your stack.
*Score: ___ / 10*

### 9. Production Guardrails
- [ ] Auth, tenant isolation, and permissions operate in deterministic code—never delegated to prompts.
- [ ] Output filtering checks for data leakage before delivering responses back to clients.
*Score: ___ / 10*

### 10. End-to-End Adversarial Testing
- [ ] CI/CD test suites run evaluations against malformed JSON, tool 500 errors, and hostile inputs.
- [ ] Deterministic eval metrics assess task completion accuracy outside of manual testing.
*Score: ___ / 10*

---

### Final Readiness Index
* **90 – 100:** Production Ready. Architectural boundaries are properly isolated.
* **75 – 89:** Moderate Exposure. Address missing retry boundaries and context budgeting.
* **50 – 74:** High Failure Risk. Prompt-level assumptions are substituting for application code.
* **< 50:** Critical Vulnerability. Fragile architecture will break under production concurrency.

---
*© 2026 Agentic Architecture. Independent Developer Edition.*
